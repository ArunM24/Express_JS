const express = require("express");

const router = express.Router();

let userTaskModeel = ('../models/user_task_model')

router.post('/createUserTask',(req,res)=>{

    const userTask = new userTaskModeel({
        taskTitle: req.body.myTaskTitle,
        taskDiscription: req.body.myTaskDiscription,
    });
   /* try{
        const newUserTask = await usertask.save();
        res.status(201).json(newUserTask);
    }catch(error)
    {
        res.status(400).json({msg:error});
    }*/
}
);

module.exports = router;