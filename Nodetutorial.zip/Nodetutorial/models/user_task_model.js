let mongoose = require("mongoose");
let userTaskSchema = mongoose.Schema({
    taskTitle:{
        type: String,
        required=true,
    },
    taskDiscription:{
        type: String,
    }
});
module.exports = mongoose.model("userTaskModeel",userTaskSchema);